import React, { useState, useEffect } from "react";
import Navbar from "../../components/common/Navbar";
import { useSelector } from "react-redux";
import { useNavigate, useLocation } from "react-router-dom";
import MovieSeriesCard from "../../components/Cards/MovieSeriesCard";
import { connect } from "react-redux";
import * as seriesAction from "../../action/seriesAction";
import { withHttp } from "../../constant/helper";
import NoResultFound from "../../components/common/NoResultFound";
import { CATEGORY_TYPE } from "../../constant/enum";
import LabelText from "../../components/typography/labelText";

function Series({
  seriesInfo,
  addFavouriteSeries,
  removeFavouriteSeries,
  callPlayedSeries,
}) {
  const navigate = useNavigate();
  const location = useLocation();
  const seriesList = useSelector(
    (state) => state.seriesReducer?.seriesChannels
  );

  const recentPlayedSeries = useSelector(
    (state) => state.seriesReducer?.seriesRecentPlayed
  );

  const { username, password } = useSelector(
    (state) => state.loginReducer?.userDetails?.user_info
  );
  const { url, port } = useSelector(
    (state) => state.loginReducer?.userDetails?.server_info
  );
  const favouriteSeries = useSelector(
    (state) => state?.seriesReducer?.allFavouriteSeries
  );
  const recentSeries = useSelector(
    (state) => state?.seriesReducer?.seriesRecentPlayed
  );

  let categoryOfSeries;
  switch (location?.state?.categoryType) {
    case CATEGORY_TYPE?.FAVOURITES:
      categoryOfSeries = favouriteSeries;
      break;
    case CATEGORY_TYPE?.RECENT_PLAYED:
      categoryOfSeries = recentSeries;
      break;
    default:
      categoryOfSeries = seriesList;
      break;
  }
  const [currentFavouriteClicked, setCurrentFavouriteCliked] = useState([]);
  const [reRender, setRerender] = useState(false);
  const [dataToShow, setDataToShow] = useState(categoryOfSeries);
  const getSeriesInformation = async (streamId, series) => {
    const seriesInfoUrl = `${withHttp(
      url
    )}:${port}/player_api.php?username=${username}&password=${password}&action=get_series_info&series_id=${streamId}`;
    const seriesInfoResponse = await seriesInfo(seriesInfoUrl);
    if (seriesInfoResponse?.status === 200) {
      const isSeriesAlreadyPlayed = recentPlayedSeries?.find(
        (item) => item?.series_id === series?.series_id
      );
      if (!isSeriesAlreadyPlayed) {
        await callPlayedSeries(series);
      }
      navigate("/series-info", {
        state: {
          series: series,
        },
      });
    }
  };

  const handleDataReceived = (data) => {
    setDataToShow(data);
  };
  const searchQuery = (query) => {
    if (query === "") {
      setDataToShow(categoryOfSeries);
    }
  };

  const addToFavourites = async (event, seriesData) => {
    event.stopPropagation();
    if (seriesData?.isFavourite) {
      const indexFavouriteIcon = currentFavouriteClicked?.findIndex(
        (item) => item?.series_id === seriesData?.series_id
      );
      const afterRemovingFavourite = currentFavouriteClicked?.splice(
        indexFavouriteIcon,
        1
      );
      setCurrentFavouriteCliked(afterRemovingFavourite);

      // actual one
      const indexofFavouriteMovie = favouriteSeries?.findIndex(
        (item) => item?.series_id === seriesData?.series_id
      );

      favouriteSeries?.splice(indexofFavouriteMovie, 1);
      await removeFavouriteSeries(favouriteSeries);
    } else {
      setCurrentFavouriteCliked([
        ...currentFavouriteClicked,
        seriesData?.series_id,
      ]);
      const allFavouriteSeries = dataToShow?.find(
        (element) => element?.series_id === seriesData?.series_id
      );
      allFavouriteSeries.isFavourite = true;
      await addFavouriteSeries(allFavouriteSeries);
    }
  };

  function filterFavouriteSeries() {
    const commonChannels = dataToShow?.filter((list) =>
      favouriteSeries?.some(
        (favChannels) => favChannels.series_id === list.series_id
      )
    );
    commonChannels?.forEach((obj) => {
      const index = dataToShow?.findIndex(
        (obj1) => obj1.series_id === obj.series_id
      );
      dataToShow[index] = { ...dataToShow[index], isFavourite: true };
    });
  }

  useEffect(() => {
    setRerender(!reRender);
    filterFavouriteSeries();
  }, []);

  return (
    <div>
      <Navbar
        heading="Series"
        data={seriesList}
        searchResult={handleDataReceived}
        searchedString={searchQuery}
        notCategories={true}
      />
      <div className="lg:px-14 px-16">
        <LabelText
          text={`Number of Series : ${dataToShow?.length}`}
          textColor="text-white"
          fontSize="lg:text-2xl text-base"
          className="my-2"
        />

        {dataToShow?.length !== 0 ? (
          <div className="my-4 flex flex-wrap lg:gap-16 gap-8">
            {dataToShow?.map((series, index) => {
              return (
                <div key={index}>
                  <MovieSeriesCard
                    data={series}
                    heartClicked={(event) => addToFavourites(event, series)}
                    onClick={() =>
                      getSeriesInformation(series?.series_id, series)
                    }
                  />
                </div>
              );
            })}
          </div>
        ) : (
          <NoResultFound />
        )}
      </div>
    </div>
  );
}

const mapDispatchToProps = (dispatch) => {
  return {
    seriesInfo: (testLine) => dispatch(seriesAction.getSeriesinfo(testLine)),
    addFavouriteSeries: (series) =>
      dispatch(seriesAction.setSeriesTvFavourites(series)),
    removeFavouriteSeries: (favouriteSeriesList) =>
      dispatch(seriesAction.setSeriesUnFavourites(favouriteSeriesList)),
    callPlayedSeries: (playedSeries) =>
      dispatch(seriesAction.setSeriesPlayed(playedSeries)),
  };
};
export default connect(null, mapDispatchToProps)(Series);
