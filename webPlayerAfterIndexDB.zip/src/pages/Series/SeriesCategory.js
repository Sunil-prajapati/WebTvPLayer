import React, { useState, useEffect } from "react";
import CategoryButton from "../../components/buttons/CategoryButton";
import Navbar from "../../components/common/Navbar";
import { useNavigate } from "react-router-dom";
import { useSelector } from "react-redux";
import * as seriesAction from "../../action/seriesAction";
import { connect } from "react-redux";
import { getUnlockedCategories, withHttp } from "../../constant/helper";
import NoResultFound from "../../components/common/NoResultFound";
import { API_STATUS, CATEGORY_ID, CATEGORY_TYPE } from "../../constant/enum";
import FullPageLoader from "../../components/common/FullPageLoader";

function SeriesCategory({ series }) {
  const navigate = useNavigate();
  const seriesCategories = useSelector(
    (state) => state.dashboardReducer?.allSeriesCategories
  );
  const { username, password } = useSelector(
    (state) => state.loginReducer?.userDetails?.user_info
  );
  const { url, port } = useSelector(
    (state) => state.loginReducer?.userDetails?.server_info
  );
  const allLockCategories = useSelector(
    (state) => state?.livetvReducer?.lockedCategories
  );
  const [dataToShow, setDataToShow] = useState(seriesCategories);
  const [loading, setLoading] = useState(false);

  const redirectToSeriesList = async (categoryId) => {
    setLoading(true);
    if (categoryId === CATEGORY_ID.FAVOURITES) {
      navigate("/series", {
        state: { categoryType: CATEGORY_TYPE?.FAVOURITES },
      });
    } else if (categoryId === CATEGORY_ID?.RECENT_PLAYED) {
      navigate("/series", {
        state: { categoryType: CATEGORY_TYPE?.RECENT_PLAYED },
      });
    } else {
      const seriesListUrl = `${withHttp(
        url
      )}:${port}/player_api.php?username=${username}&password=${password}&action=get_series&category_id=${categoryId}`;
      const seriesListResponse = await series(seriesListUrl);
      if (seriesListResponse?.status === API_STATUS?.STATUS_200) {
        navigate("/series");
        setLoading(false);
      } else {
        setLoading(false);
      }
    }
  };

  const handleDataReceived = (data) => {
    setDataToShow(data);
  };
  const searchQuery = (query) => {
    if (query === "") {
      setDataToShow(seriesCategories);
    }
  };

  useEffect(() => {
    const newCategories = [
      {
        category_id: CATEGORY_ID.ALL,
        category_name: "ALL",
        parent_id: 0,
      },
      {
        category_id: CATEGORY_ID.FAVOURITES,
        category_name: "Favourites",
        parent_id: 0,
      },
      {
        category_id: CATEGORY_ID.RECENT_PLAYED,
        category_name: "Recent Played",
        parent_id: 3,
      },
      ...dataToShow,
    ];
    setDataToShow(newCategories);
  }, []);

  return (
    <div>
      <Navbar
        heading="Series"
        data={seriesCategories}
        searchResult={handleDataReceived}
        searchedString={searchQuery}
      />
      {getUnlockedCategories(dataToShow, allLockCategories) !== 0 ? (
        loading ? (
          <FullPageLoader />
        ) : (
          <div className="lg:px-12 flex flex-wrap lg:gap-16 gap-8 justify-center px-auto lg:my-16 my-8">
            {getUnlockedCategories(dataToShow, allLockCategories)?.map(
              (category, index) => {
                return (
                  <CategoryButton
                    categoryName={category?.category_name}
                    categoryNumber={`0${index + 1}`}
                    key={index}
                    onClick={() => redirectToSeriesList(category?.category_id)}
                  />
                );
              }
            )}
          </div>
        )
      ) : (
        <NoResultFound />
      )}
    </div>
  );
}

const mapDispatchToProps = (dispatch) => {
  return {
    series: (testLine) => dispatch(seriesAction.getSeries(testLine)),
  };
};

export default connect(null, mapDispatchToProps)(SeriesCategory);
