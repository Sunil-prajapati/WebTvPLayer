import React, { useState } from "react";
import Logo from "../../assets/logo/logo.svg";
import PosterCard from "../../components/Cards/PosterCard";
import Heading from "../../components/common/Heading";
import { useSelector } from "react-redux";
import LabelText from "../../components/typography/labelText";
import StarRating from "../../components/common/StarRating";
import "../../styles/pages/movie-info.scss";
import Heart from "../../assets/svg/heart";
import { COLORS, youtubeOpts } from "../../constant/enum";
import NormalButton from "../../components/buttons/NormalButton";
import { onReady } from "../../constant/helper";
import YouTube from "react-youtube";
import { useLocation, useNavigate } from "react-router-dom";

export default function SeriesInfo() {
  const location = useLocation();
  const [youtubeVideo, setYoutubeVideo] = useState(false);
  const seriesInfo = useSelector((state) => state.seriesReducer?.seriesInfo);
  const { info } = seriesInfo;
  const navigate = useNavigate();

  const selectedSeries = location?.state?.series

  const watchTrailor = () => {
    setYoutubeVideo(true);
  };

  const goToEpisodes = () => {
    navigate('/episodes',{state:{series:selectedSeries}})
  }

  return (
    <div>
      <img
        src={Logo}
        alt="logo"
        className="lg:w-48 w-28 lg:h-16 h-10 mt-4 lg:ml-0 ml-6 cursor-pointer"
        onClick={() => navigate('/dashboard')}
      />
      <div className="flex justify-center">
        <Heading heading={"SERIES INFO"} className="lg:w-56 w-32" />
      </div>
      <div className="flex flex-row w-full lg:gap-32 gap-10 px-8 lg:mt-7 mt-3">
        <div className="flex flex-col items-center lg:w-1/6 w-3/12">
          <PosterCard image={info?.cover} />
          <LabelText
            text={`Duration: ${info?.duration ? info?.duration : "N/A"}`}
            textColor="text-white"
            className="lg:mt-6 mt-2"
            fontSize="lg:text-2xl text-base"
          />
          <StarRating rating={info?.rating / 2} />
        </div>
        <div className="lg:w-5/6 w-9/12">
          <div className="global-border">
            <div className="lg:px-5 px-2 flex flex-row justify-between items-center">
              <LabelText
                text={info?.name ? info?.name : "N/A"}
                fontSize="lg:text-5xl text-2xl"
                className="movie-title"
                textColor="text-white"
                fontWeight="text-bold"
              />
              <div className="heart-icon">
                <Heart fill={COLORS.RED} />
              </div>
            </div>
          </div>

          <div className="global-border lg:mt-6 mt-2">
            <LabelText
              text={info?.plot ? info?.plot : "N/A"}
              fontSize="lg:text-2xl text-sm"
              className="lg:mx-5 mx-2 lg:mt-5 mt-2 lg:mb-11 mb-4"
              textColor="text-white"
            />
          </div>
          {youtubeVideo && (
            <div className="youtube-video-container lg:mt-4 mt-2">
              <YouTube
                videoId={info?.youtube_trailer}
                opts={youtubeOpts}
                onReady={onReady}
              />
            </div>
          )}
          <div className="lg:mt-6 mt-2 flex flex-row justify-center lg:gap-10 gap-4">
            <NormalButton caption="Episodes" bgColor="bg-red-100" onClick={goToEpisodes}/>
            <NormalButton caption="Seasons" onClick={goToEpisodes}/>
            <NormalButton
              caption="Watch Trailer"
              onClick={() => watchTrailor()}
            />
          </div>
          <div className="lg:mt-6 mt-2 lg:gap-2 gap-1 flex flex-col">
            <LabelText
              text={`Directed By: ${info?.director ? info?.director : "N/A"}`}
              fontSize="lg:text-2xl text-sm"
              textColor="text-white"
              fontWeight="text-normal"
            />
            <LabelText
              text={`Release Date: ${
                info?.releaseDate ? info?.releaseDate : "N/A"
              }`}
              fontSize="lg:text-2xl text-sm"
              textColor="text-white"
              fontWeight="text-normal"
            />
            <LabelText
              text={`Genre: ${info?.genre ? info?.genre : "N/A"}`}
              fontSize="lg:text-2xl text-sm"
              textColor="text-white"
              fontWeight="text-normal"
            />
          </div>
        </div>
      </div>
    </div>
  );
}
