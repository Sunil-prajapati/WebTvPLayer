import React, { useState, useEffect } from "react";
import Logo from "../../assets/logo/logo.svg";
import { useSelector } from "react-redux";
import NormalButton from "../../components/buttons/NormalButton";
import { withHttp } from "../../constant/helper";
import Dropdown from "../../components/inputs/DropDown";
import LabelText from "../../components/typography/labelText";
import "../../styles/pages/episode.scss";

function Episodes() {
  const [selectedSeason, setSelectedSeason] = useState(1);
  const [videoURL, setVideoUrl] = useState("");
  const [videoError, setVideoError] = useState(false);
  const seriesInfo = useSelector((state) => state.seriesReducer?.seriesInfo);

  const { username, password } = useSelector(
    (state) => state.loginReducer?.userDetails?.user_info
  );
  const { url, port } = useSelector(
    (state) => state.loginReducer?.userDetails?.server_info
  );
  const { episodes, seasons, info } = seriesInfo;

  const handleChange = (e) => {
    setSelectedSeason(e);
  };

  const watchNow = async (streamId, extension) => {
    setVideoUrl(
      `${withHttp(
        url
      )}:${port}/series/${username}/${password}/${streamId}.${extension}`
    );
  };

  const toggleFullScreen = () => {
    var videoPlayerElement = document.getElementById("mySeriesVideo");
    if (videoPlayerElement && videoPlayerElement.requestFullscreen) {
      videoPlayerElement.requestFullscreen();
    } else if (
      videoPlayerElement &&
      videoPlayerElement.webkitRequestFullscreen
    ) {
      /* Safari */
      videoPlayerElement.webkitRequestFullscreen();
    } else if (videoPlayerElement && videoPlayerElement.msRequestFullscreen) {
      /* IE11 */
      videoPlayerElement.msRequestFullscreen();
    }
  };
  const onVideoError = () => {
      setVideoError(true);
  };

  useEffect(() => {
    toggleFullScreen();
  }, [videoURL]);

  return (
    <div>
      <img
        src={Logo}
        alt="logo"
        className="lg:w-48 w-28 lg:h-16 h-10 mt-4 lg:ml-0 ml-6"
      />

      <div className="lg:mt-24 mt-8 mx-6">
        <div className="flex flex-row justify-between">
          <Dropdown
            handleChange={(e) => handleChange(e.target.value)}
            options={seasons}
          />
          <NormalButton caption="Episodes" bgColor="bg-red-100" />
        </div>
        {videoURL && !videoError ? (
          <div className="border series-video-container lg:mt-4 mt-2">
            <video
              id="mySeriesVideo"
              controls
              loop
              preload="metadata"
              onError={onVideoError}
              autoPlay={true}
              poster={
                info?.backdrop_path?.[0]
                  ? info?.backdrop_path?.[0]
                  : info?.cover
              }
              width="620px"
              height="335px"
              src={videoURL}
            ></video>
          </div>
        ) : videoError ? (
          <div className="border-2 border-white series-video-container rounded-lg lg:mt-4 mt-2">
            <LabelText
              text="Playback error!"
              textColor="text-white"
              textAlign="text-center"
            />
          </div>
        ) : null}
        <div className="global-border mt-4">
          <div className="flex flex-wrap justify-center lg:gap-14 gap-4 lg:py-16 py-6 ">
            {episodes?.[selectedSeason]?.map((episode, index) => {
              return (
                <div
                  className="episode-btn flex justify-center items-center cursor-pointer"
                  key={index}
                  onClick={() =>
                    watchNow(episode?.id, episode?.container_extension)
                  }
                >
                  <LabelText
                    text={`Episode ${episode?.episode_num}`}
                    fontSize="lg:text-4xl text-base"
                    className="episode-btn-text"
                    textColor="text-white"
                  />
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

export default Episodes;
