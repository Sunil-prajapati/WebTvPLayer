import React, { useState, useEffect } from "react";
import ChannelListButton from "../../components/buttons/ChannelListButton";
import Navbar from "../../components/common/Navbar";
import LabelText from "../../components/typography/labelText";
import "../../styles/pages/livetv.scss";
import { useSelector } from "react-redux";
import { useLocation } from "react-router-dom";
import * as livetvAction from "../../action/livetvAction";
import { connect } from "react-redux";
import { withHttp } from "../../constant/helper";
import NoResultFound from "../../components/common/NoResultFound";
import { CATEGORY_TYPE } from "../../constant/enum";
import EpgSection from "../../components/LiveTv/EpgSection";
import LiveVideoSection from "../../components/LiveTv/LiveVideoSection";

function LiveTv({ setLiveFavourites, removeLiveFavourite, callRecentPlayed }) {
  const location = useLocation();
  const [videoURL, setVideoUrl] = useState();
  const [selectedChannel, setSelectedChannel] = useState(null);
  const [streamID, setStreamID] = useState();
  const [reRender, setRerender] = useState(false);
  const [currentFavouriteClicked, setCurrentFavouriteCliked] = useState([]);
  const liveChannels = useSelector(
    (state) => state.livetvReducer?.livetvChannels
  );
  const liveFavouriteChannels = useSelector(
    (state) => state.livetvReducer?.liveFavouriteChannels
  );
  const liveRecentPlayedChannels = useSelector(
    (state) => state.livetvReducer?.liveRecentPlayed
  );

  let categoryOfChannels;
  switch (location?.state?.categoryType) {
    case CATEGORY_TYPE?.FAVOURITES:
      categoryOfChannels = liveFavouriteChannels;
      break;
    case CATEGORY_TYPE?.RECENT_PLAYED:
      categoryOfChannels = liveRecentPlayedChannels;
      break;
    default:
      categoryOfChannels = liveChannels;
      break;
  }

  const [dataToShow, setDataToShow] = useState(categoryOfChannels);
  const { username, password } = useSelector(
    (state) => state.loginReducer?.userDetails?.user_info
  );
  const { url, port } = useSelector(
    (state) => state.loginReducer?.userDetails?.server_info
  );

  const playLiveTV = (streamId) => {
    setSelectedChannel(streamId);
    setVideoUrl(
      `${withHttp(url)}:${port}/live/${username}/${password}/${streamId}.m3u8`
    );
  };
  const play = async (streamId, channel) => {
    setStreamID(streamId);
    await playLiveTV(streamId);
    const isChannelAlreadyPlayed = liveRecentPlayedChannels?.find(
      (item) => item?.stream_id === streamId
    );
    if(!isChannelAlreadyPlayed){
      await callRecentPlayed(channel);
    }
  };

  const handleDataReceived = (data) => {
    setDataToShow(data);
  };
  const searchQuery = (query) => {
    if (query === "") {
      setDataToShow(categoryOfChannels);
    }
  };

  const heartClicked = async (event, data) => {
    event.stopPropagation();
    if (data?.isFavourite) {
      // REMOVING FAVOURITE CHANNEL ICON
      const indexFavouriteIcon = currentFavouriteClicked.findIndex(
        (item) => item.stream_id === data.stream_id
      );
      const afterRemovingFavourite = currentFavouriteClicked.splice(
        indexFavouriteIcon,
        1
      );
      setCurrentFavouriteCliked(afterRemovingFavourite);
      // REMOVING FAVOURITE CHANNEL FROM REDUCER
      const indexofFavouriteChannel = liveFavouriteChannels.findIndex(
        (item) => item.stream_id === data.stream_id
      );
      liveFavouriteChannels.splice(indexofFavouriteChannel, 1);
      await removeLiveFavourite(liveFavouriteChannels);
    } else {
      setCurrentFavouriteCliked([...currentFavouriteClicked, data?.stream_id]);
      const favouriteChannelObject = dataToShow?.find(
        (element) => element?.stream_id === data?.stream_id
      );
      await setLiveFavourites(favouriteChannelObject);
    }
  };

  function filterOutFavouriteChannels() {
    const commonChannels = dataToShow?.filter((list) =>
      liveFavouriteChannels?.some(
        (favChannels) => favChannels.stream_id === list.stream_id
      )
    );
    commonChannels?.forEach((obj) => {
      const index = dataToShow?.findIndex(
        (obj1) => obj1.stream_id === obj.stream_id
      );
      dataToShow[index] = { ...dataToShow[index], isFavourite: true };
    });
  }

  const requestOrientationLock = async () => {
    if (window.screen.orientation && window.screen.orientation.lock) {
      try {
        await window.screen.orientation.lock("landscape");
        console.log("Orientation locked successfully.");
      } catch (error) {
        console.error("Failed to lock the orientation:", error);
      }
    } else {
      console.error("Screen orientation API not supported.");
    }
  };
  useEffect(() => {
    setRerender(!reRender);
    filterOutFavouriteChannels();
    requestOrientationLock();
    return () => {
      window.removeEventListener("orientationchange", requestOrientationLock);
    };
  }, []);

  return (
    <div>
      <Navbar
        data={dataToShow}
        searchResult={handleDataReceived}
        searchedString={searchQuery}
        notCategories={true}
        searchByNum={true}
      />
      <div className="live-tv-main-container flex flex-row w-full">
        <div className="flex flex-col lg:px-8 px-2 w-full">
          <LiveVideoSection
            setVideoUrl={setVideoUrl}
            videoURL={videoURL}
            selectedChannel={selectedChannel}
          />
          <EpgSection
            streamId={streamID}
            categoryName={location?.state?.categoryName}
          />
        </div>
        <div className="w-full lg:pr-8 pr-2 live-channels-container">
          <div className="flex flex-row justify-center gap gap-2 mt-1">
            <LabelText
              text={`${location?.state?.categoryName} (${dataToShow?.length})`}
              fontSize="lg:text-3xl text-xl"
              fontWeight="font-bold"
              textColor="text-white"
            />
          </div>
          {dataToShow?.length !== 0 ? (
            <div className="mt-2">
              {dataToShow?.map((channel, index) => {
                return (
                  <div
                    className="lg:mb-9 mb-4 cursor-pointer"
                    key={index}
                    onClick={() => play(channel?.stream_id, channel)}
                  >
                    <ChannelListButton
                      onClick={(event) => heartClicked(event, channel)}
                      data={channel}
                      favouriteClickedStreamId={currentFavouriteClicked}
                      isActive={
                        channel?.stream_id === selectedChannel ? true : false
                      }
                    />
                  </div>
                );
              })}
            </div>
          ) : (
            <NoResultFound />
          )}
        </div>
      </div>
    </div>
  );
}

const mapDispatchToProps = (dispatch) => {
  return {
    setLiveFavourites: (channelList) =>
      dispatch(livetvAction.setLiveTvFavourites(channelList)),
    removeLiveFavourite: (channelList) =>
      dispatch(livetvAction.setLiveTvUnFavourites(channelList)),
    callRecentPlayed: (channel) =>
      dispatch(livetvAction.setLiveTvPlayed(channel)),
  };
};

export default connect(null, mapDispatchToProps)(LiveTv);
