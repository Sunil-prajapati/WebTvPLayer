import React, { useState, useRef, useEffect } from "react";
import Logo from "../../assets/logo/logo.svg";
import PosterCard from "../../components/Cards/PosterCard";
import Heading from "../../components/common/Heading";
import { useSelector } from "react-redux";
import LabelText from "../../components/typography/labelText";
import StarRating from "../../components/common/StarRating";
import "../../styles/pages/movie-info.scss";
import Heart from "../../assets/svg/heart";
import { COLORS, youtubeOpts } from "../../constant/enum";
import NormalButton from "../../components/buttons/NormalButton";
import { onReady, withHttp } from "../../constant/helper";
import YouTube from "react-youtube";
import { useLocation, useNavigate } from "react-router-dom";
import * as moviesAction from "../../action/moviesAction";
import { connect } from "react-redux";

function MoviesInfo({ callRecentPlayed }) {
  const location = useLocation();
  const [videoURL, setVideoUrl] = useState(false);
  const videoRef = useRef(null);
  const [youtubeVideo, setYoutubeVideo] = useState();
  const [videoError, setVideoError] = useState(false);
  const movieInfo = useSelector((state) => state.movieReducer?.movieInfo);
  const recentPlayedList = useSelector(
    (state) => state.movieReducer?.movieRecentPlayed
  );

  const navigate = useNavigate();

  const selectedMovie = location?.state?.movie;

  const { username, password } = useSelector(
    (state) => state.loginReducer?.userDetails?.user_info
  );
  const { url, port } = useSelector(
    (state) => state.loginReducer?.userDetails?.server_info
  );
  const { info, movie_data } = movieInfo;

  let video = `${withHttp(url)}:${port}/movie/${username}/${password}/${
    movie_data?.stream_id
  }.${movie_data?.container_extension}`;

  const watchNow = async () => {
    setVideoUrl(true);
    const isMovieAlreadyPlayed = recentPlayedList?.find(
      (item) => item?.stream_id === movie_data?.stream_id
    );
    if (!isMovieAlreadyPlayed) {
      await callRecentPlayed(selectedMovie);
    }
  };

  const watchTrailor = () => {
    setYoutubeVideo(`https://www.youtube.com/watch?v=${info?.youtube_trailer}`);
  };

  const toggleFullScreen = () => {
    var videoPlayerElement = document.getElementById("myvideo");
    if (videoPlayerElement && videoPlayerElement.requestFullscreen) {
      videoPlayerElement.requestFullscreen();
    } else if (
      videoPlayerElement &&
      videoPlayerElement.webkitRequestFullscreen
    ) {
      /* Safari */
      videoPlayerElement.webkitRequestFullscreen();
    } else if (videoPlayerElement && videoPlayerElement.msRequestFullscreen) {
      /* IE11 */
      videoPlayerElement.msRequestFullscreen();
    }
  };

  useEffect(() => {
    toggleFullScreen();
  }, [videoURL]);

  const onVideoError = () => {
    setVideoError(true);
  };

  return (
    <div>
      <img
        src={Logo}
        alt="logo"
        className="lg:w-48 w-28 lg:h-16 h-10 mt-4 lg:ml-0 ml-6 cursor-pointer"
        onClick={() => navigate("/dashboard")}
      />
      <div className="flex justify-center">
        <Heading heading={"MOVIE INFO"} className="lg:w-56 w-32" />
      </div>
      <div className="flex flex-row w-full lg:gap-32 gap-10 px-8 lg:mt-7 mt-3">
        <div className="flex flex-col items-center lg:w-1/6 w-3/12">
          <PosterCard
            image={info?.movie_image ? info?.movie_image : info?.cover_big}
          />
          <LabelText
            text={`Duration: ${info?.duration ? info?.duration : "N/A"}`}
            textColor="text-white"
            className="lg:mt-6 mt-2"
            fontSize="lg:text-2xl text-base"
          />
          <StarRating rating={info?.rating / 2} />
        </div>
        <div className="lg:w-5/6 w-9/12">
          <div className="global-border">
            <div className="lg:px-5 px-2 flex flex-row justify-between items-center">
              <LabelText
                text={info?.name ? info?.name : "N/A"}
                fontSize="lg:text-5xl text-2xl"
                className="movie-title"
                textColor="text-white"
                fontWeight="text-bold"
              />
              <div className="heart-icon">
                <Heart fill={COLORS.RED} />
              </div>
            </div>
          </div>

          <div className="global-border lg:mt-6 mt-2">
            <LabelText
              text={info?.plot ? info?.plot : "N/A"}
              fontSize="lg:text-2xl text-sm"
              className="lg:mx-5 mx-2 lg:mt-5 mt-2 lg:mb-11 mb-4"
              textColor="text-white"
            />
          </div>

          {videoURL && !videoError ? (
            <div
              className="movies-video-container lg:mt-4 mt-2"
              id="player_container"
            >
              <video
                ref={videoRef}
                id="myvideo"
                controls
                loop
                preload="metadata"
                onError={onVideoError}
                autoPlay={true}
                poster={
                  info?.backdrop ? info?.backdrop : info?.backdrop_path?.[0]
                }
                width="620px"
                height="335px"
                src={video}
              ></video>
            </div>
          ) : videoError ? (
            <div className="movies-video-container flex justify-center items-center h-full border-2 border-white rounded-lg lg:mt-4 mt-2">
              <LabelText
                text="Playback error!"
                textColor="text-white"
                textAlign="text-center"
              />
            </div>
          ) : null}
          {youtubeVideo && (
            <div className="youtube-video-container lg:mt-4 mt-2">
              <YouTube
                videoId={info?.youtube_trailer}
                opts={youtubeOpts}
                onReady={onReady}
              />
            </div>
          )}
          <div className="lg:mt-6 mt-2 flex flex-row justify-center lg:gap-10 gap-4">
            <NormalButton
              caption="Watch Now"
              bgColor="bg-red-100"
              onClick={() => watchNow()}
            />
            <NormalButton
              caption="Watch Trailer"
              onClick={() => watchTrailor()}
            />
          </div>
          <div className="lg:mt-6 mt-2 lg:gap-2 gap-1 flex flex-col">
            <LabelText
              text={`Directed By: ${info?.director ? info?.director : "N/A"}`}
              fontSize="lg:text-2xl text-sm"
              textColor="text-white"
              fontWeight="text-normal"
            />
            <LabelText
              text={`Release Date: ${
                info?.releasedate ? info?.releasedate : "N/A"
              }`}
              fontSize="lg:text-2xl text-sm"
              textColor="text-white"
              fontWeight="text-normal"
            />
            <LabelText
              text={`Genre: ${info?.genre ? info?.genre : "N/A"}`}
              fontSize="lg:text-2xl text-sm"
              textColor="text-white"
              fontWeight="text-normal"
            />
          </div>
        </div>
      </div>
    </div>
  );
}

const mapDispatchToProps = (dispatch) => {
  return {
    callRecentPlayed: (movie) => dispatch(moviesAction.setMoviePlayed(movie)),
  };
};
export default connect(null, mapDispatchToProps)(MoviesInfo);
