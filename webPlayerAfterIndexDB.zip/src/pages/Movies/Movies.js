import React, { useEffect, useState } from "react";
import Navbar from "../../components/common/Navbar";
import { useSelector } from "react-redux";
import { useNavigate, useLocation } from "react-router-dom";
import MovieSeriesCard from "../../components/Cards/MovieSeriesCard";
import * as moviesAction from "../../action/moviesAction";
import { connect } from "react-redux";
import { withHttp } from "../../constant/helper";
import NoResultFound from "../../components/common/NoResultFound";
import { CATEGORY_TYPE } from "../../constant/enum";
import LabelText from "../../components/typography/labelText";

function Movies({ movieInfo, addFavouriteMovies, removeFavouriteMovie }) {
  const navigate = useNavigate();
  const location = useLocation();
  const [reRender, setRerender] = useState(false);
  const [currentFavouriteClicked, setCurrentFavouriteCliked] = useState([]);
  const moviesList = useSelector((state) => state.movieReducer?.moviesChannels);
  const { username, password } = useSelector(
    (state) => state.loginReducer?.userDetails?.user_info
  );
  const { url, port } = useSelector(
    (state) => state.loginReducer?.userDetails?.server_info
  );
  const favouriteMovies = useSelector(
    (state) => state?.movieReducer?.allFavouriteMovies
  );
  const recentPlayedMovies = useSelector(
    (state) => state?.movieReducer?.movieRecentPlayed
  );


  let categoryOfMovies;
  switch (location?.state?.categoryType) {
    case CATEGORY_TYPE?.FAVOURITES:
      categoryOfMovies = favouriteMovies;
      break;
      case CATEGORY_TYPE?.RECENT_PLAYED:
        categoryOfMovies = recentPlayedMovies;
        break;
    default:
      categoryOfMovies = moviesList;
      break;
  }

  const [dataToShow, setDataToShow] = useState(categoryOfMovies);

  const getMovieInformation = async (streamId, movie) => {
    const movieInfoUrl = `${withHttp(
      url
    )}:${port}/player_api.php?username=${username}&password=${password}&action=get_vod_info&vod_id=${streamId}`;
    const movieInfoResponse = await movieInfo(movieInfoUrl);
    if (movieInfoResponse?.status === 200) {
      navigate("/dashboard/moviesCategories/movies/movie-info", {
        state: { movie: movie },
      });
    }
  };
  const handleDataReceived = (data) => {
    setDataToShow(data);
  };
  const searchQuery = (query) => {
    if (query === "") {
      setDataToShow(categoryOfMovies);
    }
  };

  const addToFavourite = async (event, movieData) => {
    event.stopPropagation();
    if (movieData?.isFavourite) {
      const indexFavouriteIcon = currentFavouriteClicked?.findIndex(
        (item) => item.stream_id === movieData.stream_id
      );
      const afterRemovingFavourite = currentFavouriteClicked?.splice(
        indexFavouriteIcon,
        1
      );
      setCurrentFavouriteCliked(afterRemovingFavourite);
      // actual one
      const indexofFavouriteMovie = favouriteMovies?.findIndex(
        (item) => item.stream_id === movieData.stream_id
      );

      favouriteMovies?.splice(indexofFavouriteMovie, 1);
      await removeFavouriteMovie(favouriteMovies);
    } else {
      setCurrentFavouriteCliked([
        ...currentFavouriteClicked,
        movieData?.stream_id,
      ]);
      const allFavouriteMovies = dataToShow?.find(
        (element) => element?.stream_id === movieData?.stream_id
      );
      allFavouriteMovies.isFavourite = true;
      await addFavouriteMovies(allFavouriteMovies);
    }
  };

  function filterFavouriteMovies() {
    const commonChannels = dataToShow?.filter((list) =>
      favouriteMovies?.some(
        (favChannels) => favChannels.stream_id === list.stream_id
      )
    );
    commonChannels?.forEach((obj) => {
      const index = dataToShow?.findIndex(
        (obj1) => obj1.stream_id === obj.stream_id
      );
      dataToShow[index] = { ...dataToShow[index], isFavourite: true };
    });
  }

  useEffect(() => {
    setRerender(!reRender);
    filterFavouriteMovies();
  }, []);

  return (
    <div>
      <Navbar
        heading="Movies"
        data={moviesList}
        searchResult={handleDataReceived}
        searchedString={searchQuery}
        notCategories={true}
      />
      <div className="lg:px-14 px-16">
        <LabelText
          text={`Number of Movies : ${dataToShow?.length}`}
          textColor="text-white"
          fontSize="lg:text-2xl text-base"
          className="my-2"
        />
        {dataToShow?.length !== 0 ? (
          <div className="my-4  flex flex-wrap lg:gap-16 gap-8">
            {dataToShow?.map((movie, index) => {
              return (
                <div key={index}>
                  <MovieSeriesCard
                    heartClicked={(event) => addToFavourite(event, movie)}
                    data={movie}
                    favouriteClickedStreamId={currentFavouriteClicked}
                    onClick={() => getMovieInformation(movie?.stream_id, movie)}
                  />
                </div>
              );
            })}
          </div>
        ) : (
          <NoResultFound />
        )}
      </div>
    </div>
  );
}

const mapDispatchToProps = (dispatch) => {
  return {
    movieInfo: (testLine) => dispatch(moviesAction.getMovieinfo(testLine)),
    addFavouriteMovies: (movie) =>
      dispatch(moviesAction.setMovieTvFavourites(movie)),
    removeFavouriteMovie: (favouriteMovieList) =>
      dispatch(moviesAction.setMovieUnFavourites(favouriteMovieList)),
  };
};
export default connect(null, mapDispatchToProps)(Movies);
