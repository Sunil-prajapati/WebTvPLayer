import React from "react";
import LabelText from "../typography/labelText";
import PlayButtonImg from "../../assets/svg/PlayButton.svg";

export const PlayButton = ({ onClick }) => {
  return (
    <div className="bg-rgbaColor-300 cursor-pointer w-fit" onClick={onClick}>
      <div className="lg:p-[17.86px] p-[8px] flex flex-row lg:gap-4 gap-3 items-center justify-center">
        <img
          src={PlayButtonImg}
          alt="button icon"
          className="lg:w-[37px] w-[24] lg:h-[43px] h-[24px]"
        />
        <LabelText
          text="Watch now"
          textColor="text-white"
          fontSize="lg:text-[37.212px] text-[18px]"
        />
      </div>
    </div>
  );
};
