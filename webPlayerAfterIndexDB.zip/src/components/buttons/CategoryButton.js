import React from "react";
import "../../styles/component/buttons.scss";
import LabelText from "../typography/labelText";
import PropTypes from "prop-types";

export default function CategoryButton({ categoryName, categoryNumber,onClick }) {
  return (
    <div className="category-btn-container cursor-pointer" onClick={onClick}>
      <div className="category-btn flex flex-col lg:mx-3 mx-1 lg:my-2 my-1">
        <div className="lg:px-5 px-2 py-1">
          <LabelText
            text={categoryName}
            className="category-name"
            noWrap={true}
            textColor="text-white"
          />
          <LabelText
            text={categoryNumber}
            fontSize="lg:text-base category-id"
            textColor="text-white"
          />
        </div>
      </div>
    </div>
  );
}

CategoryButton.propTypes = {
  categoryName: PropTypes.string,
  onClick: PropTypes.any,
};
CategoryButton.defaultProps = {
  categoryName: "All",
};
