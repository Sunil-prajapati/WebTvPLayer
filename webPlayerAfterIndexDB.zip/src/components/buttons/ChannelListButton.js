import React from "react";
import LabelText from "../typography/labelText";
import "../../styles/component/buttons.scss";
import Heart from "../../assets/svg/heart";
import PropTypes from "prop-types";
import { COLORS } from "../../constant/enum";
export default function ChannelListButton({
  data,
  isActive,
  onClick,
  favouriteClickedStreamId,
}) {
  return (
    <div
      className={`${
        isActive ? "channel-list-btn-active" : "channel-list-btn"
      } flex flex-row justify-between channel-list-btn-container`}
    >
      <div className="channel-list-btn-content  flex flex-row items-center gap-2 lg:ml-4 ml-1">
        <LabelText
          fontSize="lg:text-3xl text-base"
          text={`${data?.num}.`}
          fontWeight="font-light"
          textColor="text-white"
        />
        <img
          src={data?.stream_icon}
          className="channel-btn-logo"
          alt="channel-logo"
        />
        <LabelText
          text={data?.name}
          textColor="text-white"
          fontSize="lg:text-3xl text-base"
        />
      </div>
      <div
        className="channel-btn-heart flex self-center lg:mr-4 mr-1 cursor-pointer"
        onClick={(event) => onClick(event)}
      >
        <Heart
          fill={
            data?.isFavourite ||
            favouriteClickedStreamId.includes(data?.stream_id)
              ? COLORS.RED
              : COLORS.WHITE
          }
        />
      </div>
    </div>
  );
}

ChannelListButton.propTypes = {
  data: PropTypes.any,
  onClick: PropTypes.func,
  favouriteClickedStreamId: PropTypes.any,
};
