import React from "react";
import LabelText from "../typography/labelText";
import PropTypes from "prop-types";

const CategoriesList = ({ data, onClick, bgColor }) => {
  return (
    <div
      className={`lg:w-[400px] w-[250px] lg:h-[64.816px] h-auto flex-shrink-0 rounded-[1.178px] border border-rgbaColor-100 cursor-pointer ${bgColor}`}
      onClick={onClick}
    >
      <div className="flex flex-row justify-between lg:p-4 p-3">
        <LabelText
          text={data?.[0]?.group_title}
          textColor="text-white"
          fontWeight="font-normal"
          fontSize="lg:text-[21.122px] text-[13px]"
        />
        <LabelText
          text={data?.length}
          textColor="text-white"
          fontWeight="font-normal"
          fontSize="lg:text-[20.623px] text-[12px]"
        />
      </div>
    </div>
  );
};

export default CategoriesList;

CategoriesList.propTypes = {
  data: PropTypes.object,
  onClick: PropTypes.func,
  bgColor: PropTypes.string,
};
