import React from "react";
import LabelText from "../typography/labelText";
import { addDefaultSrc } from "../../constant/helper";

const NewMoviesSeriesCard = ({ onClick, data }) => {
  return (
    <div
      className="lg:h-[215.46px] h-[180px] lg:w-[145px] w-auto rounded-md flex justify-center relative cursor-pointer"
      onClick={() => onClick(data)}
    >
      <img
        onError={addDefaultSrc}
        src={data?.tvg_logo}
        alt="movie-series"
        className="rounded-md"
      />
      <LabelText
        text={data?.tvg_name}
        textColor="text-white"
        fontSize="lg:text-base text-[12px]"
        className="absolute bottom-0 bg-slate-800 filter--tw-grayscale w-full"
      />
    </div>
  );
};

export default NewMoviesSeriesCard;
